wget http://cs682.stanford.edu/imagenet_val_25.npz
