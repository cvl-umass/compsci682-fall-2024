wget "http://cs682.stanford.edu/coco_captioning.zip"
unzip coco_captioning.zip
rm coco_captioning.zip
